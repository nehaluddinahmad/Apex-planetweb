// DOM Elements
const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
const mainNav = document.querySelector('.main-nav ul');
const searchToggle = document.querySelector('.search-toggle');
const searchBar = document.querySelector('.search-bar');

// Mobile Menu Toggle
mobileMenuToggle.addEventListener('click', () => {
    const isExpanded = mobileMenuToggle.getAttribute('aria-expanded') === 'true';
    mobileMenuToggle.setAttribute('aria-expanded', !isExpanded);
    mainNav.classList.toggle('show');
});

// Search Toggle
searchToggle.addEventListener('click', () => {
    searchBar.style.display = searchBar.style.display === 'block' ? 'none' : 'block';
});

// Close search when clicking outside
document.addEventListener('click', (e) => {
    if (!searchToggle.contains(e.target) && !searchBar.contains(e.target)) {
        searchBar.style.display = 'none';
    }
});

// Cart Count (would be updated from cart.js)
function updateCartCount(count) {
    document.querySelector('.cart-count').textContent = count;
}

// Initialize cart count
updateCartCount(0);

// Product Data (would normally come from an API)
const products = [
    {
        id: 1,
        name: 'Wireless Bluetooth Headphones',
        price: 99.99,
        originalPrice: 129.99,
        image: 'assets/products/headphones.jpg',
        rating: 4.5,
        badge: 'Sale'
    },
    {
        id: 2,
        name: 'Smart Watch with Fitness Tracker',
        price: 149.99,
        originalPrice: 179.99,
        image: 'assets/products/smartwatch.jpg',
        rating: 4.2,
        badge: 'New'
    },
    {
        id: 3,
        name: 'Portable Bluetooth Speaker',
        price: 59.99,
        image: 'assets/products/speaker.jpg',
        rating: 4.7
    },
    {
        id: 4,
        name: 'Ultra HD 4K Smart TV',
        price: 799.99,
        originalPrice: 899.99,
        image: 'assets/products/tv.jpg',
        rating: 4.8,
        badge: 'Popular'
    }
];

// Load Featured Products
document.addEventListener('DOMContentLoaded', () => {
    const featuredProductsContainer = document.getElementById('featured-products');
    
    if (featuredProductsContainer) {
        products.forEach(product => {
            const discount = product.originalPrice 
                ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
                : 0;
            
            const productCard = document.createElement('div');
            productCard.className = 'product-card';
            productCard.innerHTML = `
                <div class="product-image">
                    <img src="${product.image}" alt="${product.name}" loading="lazy">
                    ${product.badge ? `<span class="product-badge">${product.badge}</span>` : ''}
                </div>
                <div class="product-info">
                    <h3 class="product-title">${product.name}</h3>
                    <div class="product-price">
                        <span class="current-price">$${product.price.toFixed(2)}</span>
                        ${product.originalPrice ? `<span class="original-price">$${product.originalPrice.toFixed(2)}</span>` : ''}
                        ${discount > 0 ? `<span class="discount">${discount}% OFF</span>` : ''}
                    </div>
                    <div class="product-rating">
                        ${'★'.repeat(Math.floor(product.rating))}${'☆'.repeat(5 - Math.floor(product.rating))}
                        <span>(${product.rating})</span>
                    </div>
                    <div class="product-actions">
                        <button class="add-to-cart" data-id="${product.id}">Add to Cart</button>
                        <button class="wishlist" aria-label="Add to wishlist">♥</button>
                    </div>
                </div>
            `;
            
            featuredProductsContainer.appendChild(productCard);
        });
        
        // Add event listeners to "Add to Cart" buttons
        document.querySelectorAll('.add-to-cart').forEach(button => {
            button.addEventListener('click', function() {
                const productId = this.getAttribute('data-id');
                addToCart(productId);
            });
        });
    }
});

// Cart functionality (would be in cart.js)
function addToCart(productId) {
    // In a real app, this would add the product to the cart in localStorage or send to a backend
    console.log(`Added product ${productId} to cart`);
    
    // Update cart count
    const currentCount = parseInt(document.querySelector('.cart-count').textContent);
    updateCartCount(currentCount + 1);
    
    // Show confirmation
    const confirmation = document.createElement('div');
    confirmation.className = 'cart-confirmation';
    confirmation.textContent = 'Item added to cart!';
    document.body.appendChild(confirmation);
    
    setTimeout(() => {
        confirmation.remove();
    }, 2000);
}

// Lazy loading for images
if ('IntersectionObserver' in window) {
    const lazyImages = document.querySelectorAll('img[loading="lazy"]');
    
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src || img.src;
                img.removeAttribute('loading');
                observer.unobserve(img);
            }
        });
    });
    
    lazyImages.forEach(img => {
        imageObserver.observe(img);
    });
}