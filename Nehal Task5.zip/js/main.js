// DOM Elements
const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
const mainNav = document.querySelector('.main-nav ul');
const searchToggle = document.querySelector('.search-toggle');
const searchBar = document.querySelector('.search-bar');

// Mobile Menu Toggle
if (mobileMenuToggle) {
    mobileMenuToggle.addEventListener('click', () => {
        const isExpanded = mobileMenuToggle.getAttribute('aria-expanded') === 'true';
        mobileMenuToggle.setAttribute('aria-expanded', !isExpanded);
        mainNav.classList.toggle('show');
    });
}

// Search Toggle
if (searchToggle) {
    searchToggle.addEventListener('click', () => {
        searchBar.style.display = searchBar.style.display === 'block' ? 'none' : 'block';
    });

    // Close search when clicking outside
    document.addEventListener('click', (e) => {
        if (!searchToggle.contains(e.target) && !searchBar.contains(e.target)) {
            searchBar.style.display = 'none';
        }
    });
}

// Cart Count (would be updated from cart.js)
function updateCartCount(count) {
    const cartCount = document.querySelector('.cart-count');
    if (cartCount) {
        cartCount.textContent = count;
    }
}

// Initialize cart count from localStorage
function initCartCount() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    updateCartCount(cart.reduce((total, item) => total + item.quantity, 0));
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    initCartCount();
    
    // Lazy loading for images
    if ('IntersectionObserver' in window) {
        const lazyImages = document.querySelectorAll('img[loading="lazy"]');
        
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.dataset.src || img.src;
                    img.removeAttribute('loading');
                    observer.unobserve(img);
                }
            });
            
            lazyImages.forEach(img => {
                imageObserver.observe(img);
            });
        }
    }
});

// Tab functionality
function setupTabs() {
    const tabHeaders = document.querySelectorAll('.tab-header .tab-link');
    const tabContents = document.querySelectorAll('.tab-content');
    
    if (tabHeaders.length > 0) {
        tabHeaders.forEach(header => {
            header.addEventListener('click', (e) => {
                e.preventDefault();
                
                // Remove active class from all headers and contents
                tabHeaders.forEach(h => h.classList.remove('active'));
                tabContents.forEach(c => c.classList.remove('active'));
                
                // Add active class to clicked header and corresponding content
                header.classList.add('active');
                const tabId = header.getAttribute('data-tab');
                document.getElementById(tabId).classList.add('active');
            });
        });
    }
}

// Thumbnail image switcher
function setupProductGallery() {
    const thumbnails = document.querySelectorAll('.thumbnail');
    const mainImage = document.getElementById('mainProductImage');
    
    if (thumbnails.length > 0 && mainImage) {
        thumbnails.forEach(thumb => {
            thumb.addEventListener('click', () => {
                // Remove active class from all thumbnails
                thumbnails.forEach(t => t.classList.remove('active'));
                
                // Add active class to clicked thumbnail
                thumb.classList.add('active');
                
                // Update main image
                const newSrc = thumb.src.replace('-thumb', '-large');
                mainImage.src = newSrc;
            });
        });
    }
}

// Quantity selector
function setupQuantitySelectors() {
    document.querySelectorAll('.quantity-selector').forEach(selector => {
        const minusBtn = selector.querySelector('.quantity-minus');
        const plusBtn = selector.querySelector('.quantity-plus');
        const input = selector.querySelector('.quantity-input');
        
        minusBtn.addEventListener('click', () => {
            let value = parseInt(input.value);
            if (value > parseInt(input.min)) {
                input.value = value - 1;
            }
        });
        
        plusBtn.addEventListener('click', () => {
            let value = parseInt(input.value);
            if (value < parseInt(input.max)) {
                input.value = value + 1;
            }
        });
    });
}

// Initialize tab and gallery functionality
document.addEventListener('DOMContentLoaded', () => {
    setupTabs();
    setupProductGallery();
    setupQuantitySelectors();
});