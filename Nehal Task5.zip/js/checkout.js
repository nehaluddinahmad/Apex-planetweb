// Checkout functionality
function initCheckoutPage() {
    // Load cart items
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    
    // Update order summary
    function updateOrderSummary() {
        let subtotal = 0;
        const summaryItems = document.querySelector('.summary-items');
        summaryItems.innerHTML = '';
        
        cart.forEach(item => {
            const product = products.find(p => p.id === item.id) || item;
            const itemTotal = product.price * item.quantity;
            subtotal += itemTotal;
            
            const summaryItem = document.createElement('div');
            summaryItem.className = 'summary-item';
            summaryItem.innerHTML = `
                <div class="item-image">
                    <img src="${product.image}" alt="${product.name}" loading="lazy">
                </div>
                <div class="item-details">
                    <h3>${product.name}</h3>
                    <div class="item-meta">
                        <span>Qty: ${item.quantity}</span>
                    </div>
                </div>
                <div class="item-price">$${itemTotal.toFixed(2)}</div>
            `;
            summaryItems.appendChild(summaryItem);
        });
        
        const shipping = document.querySelector('input[name="shipping"]:checked').value === 'expressShipping' ? 9.99 : 0;
        const tax = subtotal * 0.08; // 8% tax
        const total = subtotal + shipping + tax;
        
        document.querySelectorAll('.summary-totals .total-row')[0].querySelector('span:last-child').textContent = `$${subtotal.toFixed(2)}`;
        document.querySelectorAll('.summary-totals .total-row')[1].querySelector('span:last-child').textContent = shipping === 0 ? 'Free' : `$${shipping.toFixed(2)}`;
        document.querySelectorAll('.summary-totals .total-row')[2].querySelector('span:last-child').textContent = `$${tax.toFixed(2)}`;
        document.querySelector('.grand-total span:last-child').textContent = `$${total.toFixed(2)}`;
    }
    
    // Shipping method change
    document.querySelectorAll('input[name="shipping"]').forEach(radio => {
        radio.addEventListener('change', updateOrderSummary);
    });
    
    // Form validation
    const checkoutForm = document.getElementById('shippingForm');
    if (checkoutForm) {
        checkoutForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            // Validate form
            let isValid = true;
            const requiredFields = checkoutForm.querySelectorAll('[required]');
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    field.classList.add('error');
                    isValid = false;
                } else {
                    field.classList.remove('error');
                }
            });
            
            // Validate email
            const email = document.getElementById('email');
            if (!email.value.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
                email.classList.add('error');
                isValid = false;
            } else {
                email.classList.remove('error');
            }
            
            if (isValid) {
                // Save shipping info (in a real app, this would go to backend)
                const shippingInfo = {
                    email: document.getElementById('email').value,
                    firstName: document.getElementById('firstName').value,
                    lastName: document.getElementById('lastName').value,
                    address: document.getElementById('address').value,
                    address2: document.getElementById('address2').value,
                    city: document.getElementById('city').value,
                    country: document.getElementById('country').value,
                    state: document.getElementById('state').value,
                    zip: document.getElementById('zip').value,
                    phone: document.getElementById('phone').value,
                    saveInfo: document.getElementById('saveAddress').checked,
                    createAccount: document.getElementById('createAccount').checked
                };
                
                localStorage.setItem('shippingInfo', JSON.stringify(shippingInfo));
                
                // Proceed to payment
                window.location.href = 'checkout-payment.html';
            } else {
                showToast('Please fill in all required fields correctly');
            }
        });
    }
    
    // Initialize order summary
    updateOrderSummary();
    
    // Promo code
    document.querySelector('.promo-form button').addEventListener('click', (e) => {
        e.preventDefault();
        const code = document.querySelector('.promo-form input').value;
        if (code === 'SAVE10') {
            showToast('Coupon applied: 10% off your order!');
        } else {
            showToast('Invalid coupon code');
        }
    });
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    if (document.querySelector('.checkout-section')) {
        initCheckoutPage();
    }
});

// Show toast notification
function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast-notification';
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.remove();
    }, 3000);
}