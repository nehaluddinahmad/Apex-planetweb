// Cart functionality
let cart = JSON.parse(localStorage.getItem('cart')) || [];

// Add to cart
function addToCart(productId, quantity = 1) {
    // Find product in our data (in a real app, this would be an API call)
    const product = products.find(p => p.id === productId);
    
    if (!product) return;
    
    // Check if product already in cart
    const existingItem = cart.find(item => item.id === productId);
    
    if (existingItem) {
        existingItem.quantity += quantity;
    } else {
        cart.push({
            id: product.id,
            name: product.name,
            price: product.price,
            image: product.image,
            quantity: quantity
        });
    }
    
    // Save to localStorage
    localStorage.setItem('cart', JSON.stringify(cart));
    
    // Update cart count
    updateCartCount(cart.reduce((total, item) => total + item.quantity, 0));
    
    // Show confirmation
    showToast('Item added to cart!');
}

// Remove from cart
function removeFromCart(productId) {
    cart = cart.filter(item => item.id !== productId);
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount(cart.reduce((total, item) => total + item.quantity, 0));
    displayCartItems();
}

// Update cart item quantity
function updateCartItemQuantity(productId, quantity) {
    const item = cart.find(item => item.id === productId);
    if (item) {
        item.quantity = quantity;
        localStorage.setItem('cart', JSON.stringify(cart));
        updateCartCount(cart.reduce((total, item) => total + item.quantity, 0));
        displayCartItems();
    }
}

// Display cart items
function displayCartItems() {
    const cartItemsContainer = document.querySelector('.cart-table');
    const cartSummaryContainer = document.querySelector('.summary-items');
    
    if (!cartItemsContainer || !cartSummaryContainer) return;
    
    // Clear existing items
    const header = cartItemsContainer.querySelector('.cart-header');
    cartItemsContainer.innerHTML = '';
    cartItemsContainer.appendChild(header);
    
    cartSummaryContainer.innerHTML = '';
    
    let subtotal = 0;
    
    if (cart.length === 0) {
        cartItemsContainer.innerHTML = '<p class="empty-cart">Your cart is empty</p>';
        document.querySelector('.cart-actions .update-cart').style.display = 'none';
        document.querySelector('.checkout-btn').disabled = true;
        return;
    }
    
    // Add each item to cart
    cart.forEach(item => {
        const product = products.find(p => p.id === item.id) || item;
        const itemTotal = product.price * item.quantity;
        subtotal += itemTotal;
        
        // Add to cart table
        const cartRow = document.createElement('div');
        cartRow.className = 'cart-row';
        cartRow.innerHTML = `
            <div class="cart-item product">
                <img src="${product.image}" alt="${product.name}" loading="lazy">
                <div class="product-info">
                    <h3><a href="product-detail.html?id=${product.id}">${product.name}</a></h3>
                </div>
            </div>
            <div class="cart-item price">
                <span class="current-price">$${product.price.toFixed(2)}</span>
            </div>
            <div class="cart-item quantity">
                <div class="quantity-selector">
                    <button class="quantity-minus" aria-label="Decrease quantity">-</button>
                    <input type="number" value="${item.quantity}" min="1" max="10" class="quantity-input">
                    <button class="quantity-plus" aria-label="Increase quantity">+</button>
                </div>
            </div>
            <div class="cart-item total">
                $${itemTotal.toFixed(2)}
            </div>
            <div class="cart-item remove">
                <button class="remove-item" aria-label="Remove item">×</button>
            </div>
        `;
        cartItemsContainer.appendChild(cartRow);
        
        // Add event listeners for quantity changes
        const minusBtn = cartRow.querySelector('.quantity-minus');
        const plusBtn = cartRow.querySelector('.quantity-plus');
        const quantityInput = cartRow.querySelector('.quantity-input');
        const removeBtn = cartRow.querySelector('.remove-item');
        
        minusBtn.addEventListener('click', () => {
            let value = parseInt(quantityInput.value);
            if (value > 1) {
                quantityInput.value = value - 1;
                updateCartItemQuantity(item.id, value - 1);
            }
        });
        
        plusBtn.addEventListener('click', () => {
            let value = parseInt(quantityInput.value);
            if (value < 10) {
                quantityInput.value = value + 1;
                updateCartItemQuantity(item.id, value + 1);
            }
        });
        
        quantityInput.addEventListener('change', () => {
            let value = parseInt(quantityInput.value);
            if (value >= 1 && value <= 10) {
                updateCartItemQuantity(item.id, value);
            } else {
                quantityInput.value = item.quantity;
            }
        });
        
        removeBtn.addEventListener('click', () => {
            removeFromCart(item.id);
        });
        
        // Add to summary
        const summaryItem = document.createElement('div');
        summaryItem.className = 'summary-item';
        summaryItem.innerHTML = `
            <div class="item-image">
                <img src="${product.image}" alt="${product.name}" loading="lazy">
            </div>
            <div class="item-details">
                <h3>${product.name}</h3>
                <div class="item-meta">
                    <span>Qty: ${item.quantity}</span>
                </div>
            </div>
            <div class="item-price">$${itemTotal.toFixed(2)}</div>
        `;
        cartSummaryContainer.appendChild(summaryItem);
    });
    
    // Update totals
    const tax = subtotal * 0.08; // 8% tax
    const total = subtotal + tax;
    
    document.querySelector('.summary-totals .total-row:nth-child(1) span:last-child').textContent = `$${subtotal.toFixed(2)}`;
    document.querySelector('.summary-totals .total-row:nth-child(3) span:last-child').textContent = `$${tax.toFixed(2)}`;
    document.querySelector('.summary-totals .grand-total span:last-child').textContent = `$${total.toFixed(2)}`;
}

// Initialize cart page
function initCartPage() {
    displayCartItems();
    
    // Continue shopping button
    document.querySelector('.continue-shopping').addEventListener('click', (e) => {
        e.preventDefault();
        window.location.href = 'products.html';
    });
    
    // Update cart button
    document.querySelector('.update-cart').addEventListener('click', (e) => {
        e.preventDefault();
        // Updates are handled in real-time by other event listeners
        showToast('Cart updated!');
    });
    
    // Proceed to checkout button
    document.querySelector('.checkout-btn').addEventListener('click', (e) => {
        if (cart.length === 0) {
            e.preventDefault();
            showToast('Your cart is empty!');
        }
    });
    
    // Coupon code
    document.querySelector('.coupon-form button').addEventListener('click', (e) => {
        e.preventDefault();
        const code = document.querySelector('.coupon-form input').value;
        if (code === 'SAVE10') {
            showToast('Coupon applied: 10% off your order!');
        } else {
            showToast('Invalid coupon code');
        }
    });
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    if (document.querySelector('.cart-section')) {
        initCartPage();
    }
});

// Show toast notification
function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast-notification';
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.remove();
    }, 3000);
}