// Product data (in a real app, this would come from an API)
const products = [
    {
        id: 1,
        name: 'Wireless Bluetooth Headphones',
        price: 99.99,
        originalPrice: 129.99,
        image: 'assets/products/headphones.jpg',
        rating: 4.5,
        badge: 'Sale',
        category: 'Electronics'
    },
    {
        id: 2,
        name: 'Smart Watch with Fitness Tracker',
        price: 149.99,
        originalPrice: 179.99,
        image: 'assets/products/smartwatch.jpg',
        rating: 4.2,
        badge: 'New',
        category: 'Electronics'
    },
    {
        id: 3,
        name: 'Portable Bluetooth Speaker',
        price: 59.99,
        image: 'assets/products/speaker.jpg',
        rating: 4.7,
        category: 'Electronics'
    },
    {
        id: 4,
        name: 'Ultra HD 4K Smart TV',
        price: 799.99,
        originalPrice: 899.99,
        image: 'assets/products/tv.jpg',
        rating: 4.8,
        badge: 'Popular',
        category: 'Electronics'
    },
    {
        id: 5,
        name: 'Running Shoes',
        price: 89.99,
        image: 'assets/products/shoes.jpg',
        rating: 4.3,
        category: 'Fashion'
    },
    {
        id: 6,
        name: 'Wireless Gaming Mouse',
        price: 49.99,
        image: 'assets/products/mouse.jpg',
        rating: 4.6,
        category: 'Electronics'
    }
];

// Display products
function displayProducts(productsToDisplay) {
    const productsContainer = document.getElementById('all-products') || 
                            document.getElementById('featured-products') || 
                            document.getElementById('related-products') || 
                            document.getElementById('recently-viewed');
    
    if (!productsContainer) return;
    
    productsContainer.innerHTML = '';
    
    productsToDisplay.forEach(product => {
        const discount = product.originalPrice 
            ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
            : 0;
        
        const productCard = document.createElement('div');
        productCard.className = 'product-card';
        productCard.innerHTML = `
            <div class="product-image">
                <img src="${product.image}" alt="${product.name}" loading="lazy">
                ${product.badge ? `<span class="product-badge">${product.badge}</span>` : ''}
            </div>
            <div class="product-info">
                <h3 class="product-title">${product.name}</h3>
                <div class="product-price">
                    <span class="current-price">$${product.price.toFixed(2)}</span>
                    ${product.originalPrice ? `<span class="original-price">$${product.originalPrice.toFixed(2)}</span>` : ''}
                    ${discount > 0 ? `<span class="discount">${discount}% OFF</span>` : ''}
                </div>
                <div class="product-rating">
                    ${'★'.repeat(Math.floor(product.rating))}${'☆'.repeat(5 - Math.floor(product.rating))}
                    <span>(${product.rating})</span>
                </div>
                <div class="product-actions">
                    <button class="add-to-cart" data-id="${product.id}">Add to Cart</button>
                    <button class="wishlist" aria-label="Add to wishlist">♥</button>
                </div>
            </div>
        `;
        
        productsContainer.appendChild(productCard);
    });
    
    // Add event listeners to "Add to Cart" buttons
    document.querySelectorAll('.add-to-cart').forEach(button => {
        button.addEventListener('click', function() {
            const productId = parseInt(this.getAttribute('data-id'));
            addToCart(productId);
        });
    });
}

// Filter products
function filterProducts() {
    const categoryFilter = document.querySelector('.filter-list a.active')?.textContent.split(' ')[0];
    const priceFilter = parseInt(document.getElementById('priceRange').value);
    const sortOption = document.getElementById('sort').value;
    
    let filteredProducts = [...products];
    
    // Apply category filter
    if (categoryFilter && categoryFilter !== 'All') {
        filteredProducts = filteredProducts.filter(product => product.category === categoryFilter);
    }
    
    // Apply price filter
    filteredProducts = filteredProducts.filter(product => product.price <= priceFilter);
    
    // Apply sorting
    switch (sortOption) {
        case 'price-low':
            filteredProducts.sort((a, b) => a.price - b.price);
            break;
        case 'price-high':
            filteredProducts.sort((a, b) => b.price - a.price);
            break;
        case 'rating':
            filteredProducts.sort((a, b) => b.rating - a.rating);
            break;
        case 'newest':
            // Assuming newer products have higher IDs
            filteredProducts.sort((a, b) => b.id - a.id);
            break;
        default:
            // Default is 'popular' - we can sort by badge or rating
            filteredProducts.sort((a, b) => {
                if (a.badge === 'Popular' && b.badge !== 'Popular') return -1;
                if (b.badge === 'Popular' && a.badge !== 'Popular') return 1;
                return b.rating - a.rating;
            });
    }
    
    displayProducts(filteredProducts);
}

// Initialize product listing page
function initProductListing() {
    // Display all products initially
    displayProducts(products);
    
    // Set up filter event listeners
    document.querySelectorAll('.filter-list a').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            
            // Remove active class from all category links
            document.querySelectorAll('.filter-list a').forEach(a => a.classList.remove('active'));
            
            // Add active class to clicked link
            link.classList.add('active');
            
            // Apply filters
            filterProducts();
        });
    });
    
    // Price range filter
    const priceRange = document.getElementById('priceRange');
    if (priceRange) {
        priceRange.addEventListener('input', filterProducts);
    }
    
    // Sort option
    const sortSelect = document.getElementById('sort');
    if (sortSelect) {
        sortSelect.addEventListener('change', filterProducts);
    }
    
    // View options
    const viewGrid = document.querySelector('.view-grid');
    const viewList = document.querySelector('.view-list');
    const productGrid = document.querySelector('.product-grid');
    
    if (viewGrid && viewList && productGrid) {
        viewGrid.addEventListener('click', () => {
            viewGrid.classList.add('active');
            viewList.classList.remove('active');
            productGrid.classList.remove('list-view');
        });
        
        viewList.addEventListener('click', () => {
            viewList.classList.add('active');
            viewGrid.classList.remove('active');
            productGrid.classList.add('list-view');
        });
    }
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    initProductListing();
});