// Product detail functionality
function initProductDetail() {
    // Get product ID from URL (in a real app, this would come from backend)
    const urlParams = new URLSearchParams(window.location.search);
    const productId = urlParams.get('id') || 1;
    
    // Find product in our data (in a real app, this would be an API call)
    const product = products.find(p => p.id === parseInt(productId)) || products[0];
    
    // Update product details
    if (product) {
        document.title = `${product.name} | ShopEasy`;
        
        // Update main product info
        const discount = product.originalPrice 
            ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
            : 0;
        
        document.querySelector('.product-detail h1').textContent = product.name;
        document.querySelector('.product-rating').innerHTML = `
            ★★★★☆ <span>(${product.rating}) | 128 Reviews</span>
        `;
        document.querySelector('.current-price').textContent = `$${product.price.toFixed(2)}`;
        
        if (product.originalPrice) {
            document.querySelector('.original-price').textContent = `$${product.originalPrice.toFixed(2)}`;
            document.querySelector('.discount').textContent = `${discount}% OFF`;
        } else {
            document.querySelector('.original-price').remove();
            document.querySelector('.discount').remove();
        }
        
        // Update product description
        document.querySelector('.product-description p').textContent = product.description || 
            `Experience premium quality with our ${product.name}. Designed for performance and comfort.`;
        
        // Update images
        document.getElementById('mainProductImage').src = product.image.replace('.jpg', '-large.jpg');
        document.querySelectorAll('.thumbnail').forEach((thumb, index) => {
            thumb.src = product.image.replace('.jpg', `-thumb${index + 1}.jpg`);
        });
        
        // Add to cart button
        document.querySelector('.add-to-cart').addEventListener('click', () => {
            const quantity = parseInt(document.querySelector('.quantity-input').value);
            addToCart(product.id, quantity);
        });
    }
    
    // Display related products (in a real app, these would be from backend)
    const relatedProducts = products.filter(p => p.id !== product.id && p.category === product.category);
    displayProducts(relatedProducts.slice(0, 4), 'related-products');
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    if (document.querySelector('.product-detail')) {
        initProductDetail();
    }
});